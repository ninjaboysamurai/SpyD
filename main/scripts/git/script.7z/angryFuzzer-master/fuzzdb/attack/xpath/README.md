tool:
http://code.google.com/p/xpath-blind-explorer/

video:
http://penetration-testing.7safe.com/the-art-of-exploiting-lesser-known-injection-flaws-revealed-at-black-hat/

