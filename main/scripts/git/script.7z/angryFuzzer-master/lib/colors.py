#!/usr/bin/env python 
# -*- coding:utf-8 -*- 
class colors:
	""" Colors """
	BLUE = '\033[1;34m'
	GREEN = '\033[1;32m'
	RED = '\033[1;31m' 
	WHITE = '\033[1;37m'
	CYAN = '\033[1;36m'
	YELLOW = '\033[1;33m'
	CRIMSON = '\033[1;38m'
	RESET = '\033[0m'
	IND = '\033[04m'
	LIGHTRED = '\033[91m'
	CYAN = '\033[96m'
	MAGANTA = '\033[95m'
