set url http://slrtce.in
set url https://slrtce.in
set action_url http://slrtce.in
run

